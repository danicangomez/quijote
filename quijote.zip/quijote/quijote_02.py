import random
entrada = open('quijote.txt', 'r')
salida = open('quijote_s05.txt', 'w')
p = random.random()
for linea in entrada:
    d = random.random()
    if d <=p:
        salida.write(linea)
entrada.close()
salida.close()
        